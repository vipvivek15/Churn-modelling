# -*- coding: utf-8 -*-
"""
Created on Sat Sep  5 00:49:56 2020

@author: vipvi
"""

import numpy as np
from flask import Flask, request, jsonify, render_template
import pickle

app = Flask